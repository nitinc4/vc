package com.example.vc

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
