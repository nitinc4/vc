package com.nitin.vc

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
